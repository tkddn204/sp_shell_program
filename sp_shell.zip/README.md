# 시스템프로그래밍 쉘 프로그램
한밭대학교 학생들의 프로젝트
## 사용법
1. `cdmod 777 make.sh`
2. `./make.sh`
2. `./sp_program`
## 팀원
[tkddn204(SsangWoo)](https://github.com/tkddn204),
[ds7ggc](https://github.com/ds7ggc),
[kluge121](https://github.com/kluge121)
