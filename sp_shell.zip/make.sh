cd src/
make
